import { fromJS } from 'immutable'

export default fromJS({
  isOpenContextMenu:false,
  isEnterContextMenu:true,//鼠标是否移入右键菜单
  contextMenu:[],
  contextStyle:{},
  info:{}
})