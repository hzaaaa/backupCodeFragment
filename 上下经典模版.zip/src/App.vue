<template>
	<router-view></router-view>
</template>
<script setup lang="ts">
// import { onMounted } from "vue";
// import { useRouter } from "vue-router";
// import { initDynamicRouter } from "@/routers/modules/dynamicRouter";
// import { HOME_URL } from "@/config/config";
// const router = useRouter();

// const setupRouter = async () => {
// 	await initDynamicRouter();
// 	router.push({ path: HOME_URL });
// };

// onMounted(() => {
// 	setupRouter;
// });
</script>
