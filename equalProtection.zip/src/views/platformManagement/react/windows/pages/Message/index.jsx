import React, {Component} from 'react'

import LeftnavRightContent from "../../../components/layout/LeftnavRightContent"


class index extends Component {

  state = {}

  render() {
    return (
      <div className='system_control'>
        <LeftnavRightContent>
          <nav>
          </nav>
          <main>

          </main>
        </LeftnavRightContent>
      </div>
    )
  }
}


export default index