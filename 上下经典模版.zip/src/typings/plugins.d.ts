declare module "nprogress";
