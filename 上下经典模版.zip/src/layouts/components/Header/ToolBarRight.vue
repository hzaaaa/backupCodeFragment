<template>
	<div class="tool-bar-ri">
		<Avatar />
	</div>
</template>

<script setup lang="ts">
import {} from "vue";
import Avatar from "./components/Avatar.vue";
</script>

<style lang="scss" scoped></style>
