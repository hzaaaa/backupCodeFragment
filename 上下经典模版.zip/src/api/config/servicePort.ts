// 后端微服务端口名
/**
 * @name 鉴权mock
 */
// export const AUTHPORT = "/auth";

export const AUTHPORT = "/api-proxy-manage/auth";

/**
 * @name 业务
 */
export const PORTBiz = "/api-proxy-manage/biz";

// /**
//  * @name 表格数据mock
//  */
// export const TABLEPORT = "/table";
