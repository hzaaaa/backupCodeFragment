export const EMPTY_LIST = 'file_manage/EMPTY_LIST' //空文件列表
export const SET_FILE_LIST = 'file_manage/SET_FILE_LIST' //设置文件列表