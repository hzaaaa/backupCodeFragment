export enum ResultEnum {
  SUCCESS = 200,
  ERROR = 500,
  OVERDUE = 599, // 登录失效
  TIMEOUT = 10000,
  TYPE = "success",
}
