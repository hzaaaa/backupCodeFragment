// 默认主题颜色
export const DEFAULT_PRIMARY: string = "#00CDC4";
export const DEFAULT_WARNING: string = "#FFA42E";
