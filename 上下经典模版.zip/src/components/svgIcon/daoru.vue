<template><SvgIcon name="icon-daoru"></SvgIcon></template>
<script setup lang="ts">
import SvgIcon from "./index.vue";
</script>
