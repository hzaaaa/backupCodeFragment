import http from "@/api";
import { PORTBiz,PORTAuth } from "@/api/config/servicePort";

/**
 * @name  与hive数据库同步库表字段信息
 */

// export const getDatabaseApi = (params: any) => {
//   return http.get<any>(PORTBiz + `/table/getDatabase`, params,{
//     timeout:5*60*1000
//   });
// };



