<template>
  <div>Home</div>
</template>

<script setup lang="ts"></script>

<style scoped lang="scss"></style>
