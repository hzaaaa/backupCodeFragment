export const SET_DATE_TIME = 'home/SET_DATE_TIME' //设置日期
export const OPEN_MESSAGE_BOX = 'home/OPEN_MESSAGE_BOX' //打开消息框
export const CLOSE_MESSAGE_BOX = 'home/CLOSE_MESSAGE_BOX' //关闭消息框
export const OPEN_START_BOX = 'home/OPEN_START_BOX' //打开开始菜单
export const CLOSE_START_BOX = 'home/CLOSE_START_BOX' //关闭开始菜单
export const ADD_WINDOW_LIST = 'home/ADD_WINDOW_LIST' //添加工具栏列表
export const CLOSE_WINDOW = 'home/CLOSE_WINDOW' //关闭窗口
export const SHOW_WINDOW = 'home/SHOW_WINDOW' //显示和隐藏窗口
export const HIDDEN_WINDOW = 'home/HIDDEN_WINDOW' //隐藏窗口
export const LOAD_WINDOW = 'home/LOAD_WINDOW' //窗口读取完成
export const SET_BACKGROUND = 'home/SET_BACKGROUND' //设置桌面背景
export const SET_CONTEXT_MENU_LIST = 'home/SET_CONTEXT_MENU_LIST' //设置右键菜单
export const SET_DESKTOP_APPS_SHOW_CONTROL = 'home/SET_DESKTOP_APPS_SHOW_CONTROL' //设置桌面显示属性





