// ? 全局不动配置项 只做导出不做修改

// ** 首页地址（默认）
export const HOME_URL: string = "/";

// ** 登陆页地址（默认）
export const LOGIN_URL: string = "/login";
