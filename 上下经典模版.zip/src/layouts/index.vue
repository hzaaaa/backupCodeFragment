<template>
	<LayoutClassic />
</template>

<script setup lang="ts" name="layout">
import LayoutClassic from "@/layouts/LayoutColumns/index.vue";
</script>

<style scoped lang="scss">
.layout {
	min-width: 760px;
}
</style>
