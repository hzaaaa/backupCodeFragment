<template>
	<div>404</div>
	<div>暂无权限，请联系管理员</div>
</template>

<script setup lang="ts"></script>

<style scoped lang="scss"></style>
