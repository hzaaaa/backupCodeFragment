export const SET_CONTEXT_MENU = 'main/SET_CONTEXT_MENU' //设置右键菜单显示数据
export const IS_ENTER_CONTEXT_MENU = 'main/IS_ENTER_CONTEXT_MENU' //是否进入右键菜单

